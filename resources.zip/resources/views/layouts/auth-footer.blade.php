<hr/>
<div class="row">
    <div class="col-md-2">
        <img src="{{ asset('assets/images/dinero.png') }}" alt="small-logo.png">
    </div>
    <div class="col-md-10">
        <p class="text-inverse text-left m-b-0">Si presenta fallas, para soporte tecnico, escriba al email: <span class="text-warning">admin@jimbo.com</span>.</p>
        <p class="text-inverse text-left"><b>Jimbo sorteos, donde todos son ganadores.</b></p>
    </div>
    <div class="col-md-12">
        <p class="text-inverse text-center m-b-0">© {{date('Y')}} Jimbo Sorteos. Todos los derechos reservados.</p>
    </div>
</div>
