@extends('layouts.app', ['title' => $title ?? 'Sorteos'])

@section('page-content')
    <!-- Basic Form Inputs card start -->
    <div class="card">
        <div class="card-header">
            <h5>Fomulario de actualizacion</h5>
            <div class="card-header-right">
                <i class="icofont icofont-spinner-alt-5"></i>
            </div>
            <div class="card-header-right">
                <i class="icofont icofont-spinner-alt-5"></i>
            </div>
        </div>
        <div class="card-block">
            <h4 class="sub-title">Informacion requerida</h4>
            <form method="POST" action="{{ route('panel.raffles.update', ['raffle' => $raffle->id]) }}" name="form-raffle-edit" id="form-raffle-edit" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <input type="hidden" name="promotions_raffle" id="promotions_raffle">
                <input type="hidden" name="total" id="total">
                <input type="hidden" name="raffle_id" id="raffle_id" value="{{$raffle->id}}">
                <div class="form-group row">
                    <div class="col-sm-12">
                        <img src="{{$raffle->image != 'raffle.jpg' ? asset('assets/images/raffles/'.$raffle->image) :  asset('assets/images/raffles/raffle.jpg')}}" style= "margin: 0px 0 5px 0;" alt="Sorteo" id="raffle">
                        <br>
                        <label for="exampleFormControlFile1"><b>Imagen <i class="ti ti-info-alt" data-toggle="tooltip" data-placement="top" title="El formato de imagen debe ser (jpg, jpeg, png o svg) con unas dimensiones de 400x200 El peso maximo de la imagen es de 512 KB"></i></b></label>
                        <input type="file" name="image" id="image" file="true" class="form-control-file" id="exampleFormControlFile1">
                        <div class="col-form-label has-danger-image"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Nombre</label>
                        <input type="text" name="title" id="title" value="{{$raffle->title}}" class="form-control">
                        <div class="col-form-label has-danger-title"></div>
                    </div>
                    <div class="col-sm-6">
                        <label class="col-form-label">Marca</label>
                        <input type="text" name="brand" id="brand" value="{{$raffle->brand}}" class="form-control">
                        <div class="col-form-label has-danger-brand"></div>
                    </div>

                    <div class="col-sm-12">
                        <label class="col-form-label">Descripcion</label>
                        <textarea name="description" id="description" class="form-control" cols="10" rows="5">{{$raffle->description}}</textarea>
                        <div class="col-form-label has-danger-description"></div>
                    </div>

                    <div class="col-sm-4">
                        <label class="col-form-label">Promotor</label>
                        <input type="text" name="promoter" id="promoter" value="{{$raffle->promoter}}" class="form-control">
                        <div class="col-form-label has-danger-promoter"></div>
                    </div>

                    <div class="col-sm-4">
                        <label class="col-form-label">Proveedor</label>
                        <input type="text" name="provider" id="provider" value="{{$raffle->provider}}" class="form-control">
                        <div class="col-form-label has-danger-provider"></div>
                    </div>

                    <div class="col-sm-4">
                        <label class="col-form-label">Localidad</label>
                        <input type="text" name="place" id="place" value="{{$raffle->place}}" class="form-control">
                        <div class="col-form-label has-danger-place"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Fecha de apertura</label>
                        <div class="input-group">
                            <input type="text" name="date_start" id="date_start" value="{{$raffle->date_start->format('d/m/Y')}}" class="form-control datepicker">
                            <span class="input-group-addon" id="date_start"><i class="icofont icofont-calendar"></i></span>
                        </div>
                        <div class="col-form-label has-danger-date_start"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Fecha de cierre</label>
                        <div class="input-group">
                            <input type="text" name="date_end" id="date_end" value="{{$raffle->date_end->format('d/m/Y')}}" class="form-control datepicker">
                            <span class="input-group-addon" id="date_end"><i class="icofont icofont-calendar"></i></span>
                        </div>
                        <div class="col-form-label has-danger-date_end"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Fecha de sorteo</label>
                        <div class="input-group">
                            <input type="text" name="date_release" id="date_release" value="{{$raffle->date_release->format('d/m/Y')}}" class="form-control datepicker">
                            <span class="input-group-addon" id="date_release"><i class="icofont icofont-calendar"></i></span>
                        </div>
                        <div class="col-form-label has-danger-date_release"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Premio en Efectivo</label>
                        <div class="input-group">
                            <input type="number" min="1" name="cash_to_draw" id="cash_to_draw" value="{{intval($raffle->cash_to_draw)}}" class="form-control">
                            <span class="input-group-addon" id="cash_to_draw"><i class="icofont icofont-bill-alt"></i></span>
                        </div>
                        <div class="col-form-label has-danger-cash_to_draw"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Dinero a recolectar</label>
                        <div class="input-group">
                            <input type="number" min="1" name="cash_to_collect" id="cash_to_collect" value="{{intval($raffle->cash_to_collect)}}" class="form-control">
                            <span class="input-group-addon" id="cash_to_collect"><i class="icofont icofont-bill-alt"></i></span>
                        </div>
                        <div class="col-form-label has-danger-cash_to_collect"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Tipo</label>
                        <select name="type" id="type" class="form-control">
                            <option value="raffle" @if ($raffle->type == 'raffle') selected @endif>Sorteo</option>
                            <option value="product" @if ($raffle->type == 'product') selected @endif>Producto</option>
                        </select>
                        <div class="col-form-label has-danger-type"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Visibilidad</label>
                        <select name="public" id="public" class="form-control">
                            <option value="1" @if ($raffle->public == 1) selected @endif>Publico</option>
                            <option value="0" @if ($raffle->public == 0) selected @endif>Borrador</option>
                        </select>
                        <div class="col-form-label has-danger-public"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Estatus</label>
                        <select name="active" id="active" class="form-control">
                            <option value="1" @if ($raffle->active == 1) selected @endif>Activo</option>
                            <option value="0" @if ($raffle->active == 0) selected @endif>Inactivo</option>
                        </select>
                        <div class="col-form-label has-danger-active"></div>
                    </div>

                    <div class="col-sm-6">
                        <label class="col-form-label">Dias de prorroga</label>
                        <div class="input-group">
                            <input type="number" min="1" name="days_extend" id="days_extend" class="form-control">
                            <span class="input-group-addon" id="days_extend"><i class="icofont icofont-calendar"></i></span>
                        </div>
                        <div class="col-form-label has-danger-days_extend"></div>
                    </div>
                    <div class="col-sm-12 mt-4">
                        <div class="alert alert-warning" role="alert"><b>Porcentaje de premios en el sorteo</b></div>
                    </div>

                    <div class="col-sm-3">
                        <label class="col-form-label">1° (%)</label>
                        <input type="number" name="prize_1" id="prize_1" value="{{$raffle->prize_1}}" min="100" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_1"></div>
                    </div>

                    <div class="col-sm-3">
                        <label class="col-form-label">2° (%)</label>
                        <input type="number" name="prize_2" id="prize_2" value="{{$raffle->prize_2}}" min="1" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_2"></div>
                    </div>

                    <div class="col-sm-3">
                        <label class="col-form-label">3° (%)</label>
                        <input type="number" name="prize_3" id="prize_3" value="{{$raffle->prize_3}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_3"></div>
                    </div>

                    <div class="col-sm-3">
                        <label class="col-form-label">4° (%)</label>
                        <input type="number" name="prize_4" id="prize_4" value="{{$raffle->prize_4}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_4"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">5° (%)</label>
                        <input type="number" name="prize_5" id="prize_5" value="{{$raffle->prize_5}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_5"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">6° (%)</label>
                        <input type="number" name="prize_6" id="prize_6" value="{{$raffle->prize_6}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_6"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">7° (%)</label>
                        <input type="number" name="prize_7" id="prize_7" value="{{$raffle->prize_7}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_7"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">8° (%)</label>
                        <input type="number" name="prize_8" id="prize_8" value="{{$raffle->prize_8}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_8"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">9° (%)</label>
                        <input type="number" name="prize_9" id="prize_9" value="{{$raffle->prize_9}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_9"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">10° (%)</label>
                        <input type="number" name="prize_10" id="prize_10" value="{{$raffle->prize_10}}" min="0.6" max="100" class="form-control">
                        <div class="col-form-label has-danger-prize_10"></div>
                    </div>

                    <div class="col-sm-12 mt-4">
                        <div class="alert alert-warning" role="alert"><b>Promociones de boletos del sorteo</b></div>
                    </div>

                    <div class="col-sm-8">
                        <label class="col-form-label">Promociones</label>
                        <select name="promotions" id="promotions" class="form-control">
                            <option value="">.::Seleccione::.</option>
                            @foreach ($promotions as $key => $item)
                            <option value="{{$item->id}}">{{$item->name}}</option>
                            @endforeach
                        </select>
                        <div class="col-form-label has-danger-promotions"></div>
                    </div>

                    <div class="col-sm-2">
                        <label class="col-form-label">Cantidad de Boletos</label>
                        <input type="number" name="quantity" id="quantity" value="1" min="1" max="10000" class="form-control">
                        <div class="col-form-label has-danger-quantity"></div>
                    </div>

                    <div class="col-sm-2 mt-3">
                        <br>
                        <a href="javascript:void(0)" class="btn btn-warning btn-sm add-promotion-new" data-toggle="tooltip" data-placement="top" title="Agregar promocion de boletos"><i class="ti-plus"></i> Agregar Promocion</a>
                    </div>

                    <div class="col-sm-12">
                        {{-- <div class="col-form-label has-danger-promotions_raffle text-center"></div> --}}
                        <div class="col-form-label has-danger-total  text-center"></div>
                        <div class="add-input-content"></div>
                    </div>
                </div>
                <div class="col-md-12 text-right">
                    <a href="{{route('panel.raffles.index')}}" type="submit" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="cancelar"><i class="ti-back-left"></i></a>
                    {{-- <button type="reset" class="btn btn-inverse" data-toggle="tooltip" data-placement="top" title="Limpiar"><i class="ti-reload"></i></button> --}}
                    <button type="submit" class="btn btn-warning  btn-raffle">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Basic Form Inputs card end -->
@endsection

@section('script-content')
<script src="{{ asset('assets/js/jimbo/raffles.js') }}"></script>
@endsection
