<table align="center" class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="width:100%; max-width:600px;table-layout: fixed;" data-muid="8a8adb68-a44b-4f4a-ad93-8c124061d154" data-mc-module-version="2019-10-22">
    <tbody>
       <tr>
          <td style="padding:0px 0px 10px 20px; line-height:24px; text-align:inherit; background-color:#FFF;" height="100%" valign="top" bgcolor="#FF9a4e73" role="module-content">
             <div>
                <div style="font-family: inherit; text-align: center"><span style="box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; vertical-align: baseline; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image-source: initial; border-image-slice: initial; border-image-width: initial; border-image-outset: initial; border-image-repeat: initial; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: pre-wrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; word-break: break-all; float: none; display: inline; color: #3C3C3C; font-size: 26px; font-family: arial, helvetica, sans-serif"><strong>¿Necesitas contactar con nosotros?</strong></span><span style="font-size: 26px"><strong>&nbsp;</strong></span></div>
                <div></div>
             </div>
          </td>
       </tr>
    </tbody>
</table>
 <table align="center" border="0" cellpadding="0" cellspacing="0" align="center" width="100%" role="module" data-type="columns" style="width:100%; max-width:600px;padding:0px 0px 0px 0px;" bgcolor="#FFF" data-distribution="1,1">
    <tbody>
       <tr role="module-content">
          <td height="100%" valign="top">
             <table width="300" style="width:300px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-0">
                <tbody>
                   <tr>
                      <td style="padding:0px;margin:0px;border-spacing:0;">
                         <table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="e4a62984-44d9-4057-8df9-85eb0e4e5ecf">
                            <tbody>
                               <tr>
                                  <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="center">
                                     <img class="max-width" border="0" style="display:block; color:#3C3C3C; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px; max-width:15% !important; width:15%; height:auto !important;" width="45" alt="" data-proportionally-constrained="true" data-responsive="true" src="{{ config('app.url') }}/assets/images/phone_43x42.png">
                                  </td>
                               </tr>
                            </tbody>
                         </table>
                         <table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="c43e2f7c-1d31-4954-a6c3-9342d25a60ac" data-mc-module-version="2019-10-22">
                            <tbody>
                               <tr>
                                  <td style="padding:16px 20px 40px 20px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content">
                                     <div>
                                        <div style="font-family: inherit; text-align: center"><span style="box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; font-size: 16px; vertical-align: baseline; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image-source: initial; border-image-slice: initial; border-image-width: initial; border-image-outset: initial; border-image-repeat: initial; color: #3C3C3C; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: pre-wrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;  float: none; display: inline"><strong>(+51) 933 50 48 39</strong></span></div>
                                        <div></div>
                                     </div>
                                  </td>
                               </tr>
                            </tbody>
                         </table>
                      </td>
                   </tr>
                </tbody>
             </table>
             <table width="300" style="width:300px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-1">
                <tbody>
                   <tr>
                      <td style="padding:0px;margin:0px;border-spacing:0;">
                         <table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="9f0fd820-1dd5-4a26-86b6-4d8ce2203d13">
                            <tbody>
                               <tr>
                                  <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="center">
                                     <img class="max-width" border="0" style="display:block; color:#3C3C3C; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px; max-width:15% !important; width:15%; height:auto !important;" width="45" alt="" data-proportionally-constrained="true" data-responsive="true" src="{{ config('app.url') }}/assets/images/email_43x42.png">
                                  </td>
                               </tr>
                            </tbody>
                         </table>
                         <table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="c43e2f7c-1d31-4954-a6c3-9342d25a60ac.1" data-mc-module-version="2019-10-22">
                            <tbody>
                               <tr>
                                  <td style="padding:16px 20px 40px 20px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content">
                                     <div>
                                        <div style="font-family: inherit; text-align: center"><span style="box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; font-size: 16px; vertical-align: baseline; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image-source: initial; border-image-slice: initial; border-image-width: initial; border-image-outset: initial; border-image-repeat: initial; color: #3C3C3C; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: pre-wrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;  float: none; display: inline"><strong>info@jimbosorteos.com</strong></span></div>
                                        <div></div>
                                     </div>
                                  </td>
                               </tr>
                            </tbody>
                         </table>
                      </td>
                   </tr>
                </tbody>
             </table>
          </td>
       </tr>
    </tbody>
 </table>
