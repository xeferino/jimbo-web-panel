<table align="center" class="module" role="module" data-type="spacer" border="0" cellpadding="0" cellspacing="0" width="100%" style="width:100%; max-width:600px;table-layout: fixed;" data-muid="595dab63-af4d-4b3b-9ae7-2b67b287db51">
    <tbody>
       <tr>
          <td style="padding:0px 0px 10px 0px;" role="module-content" bgcolor="#ff9a4e">
          </td>
       </tr>
    </tbody>
 </table>

 <table align="center" class="module" role="module" data-type="code" border="0" cellpadding="0" cellspacing="0" width="100%" style="width:100%; max-width:600px;table-layout: fixed; background-color:#000000" data-muid="25be48ac-6d1d-4243-a817-978bfe9b050a">
    <tbody>
       <tr>
          <td height="100%" valign="top" role="module-content">
             <table align="center">
                <tr>
                   <td>
                      <a href="https://www.instagram.com" target="_blank">
                         <img class="responsive" style="padding-top: 20px; padding-bottom: 20px;" src="http://cdn.mcauto-images-production.sendgrid.net/ca8ed995bfca40d5/1cc43633-04c5-4d3a-b115-c56cc41edb81/43x42.png">
                      </a>
                   </td>
                   <td>
                      <a href="https://www.facebook.com" target="_blank">
                         <img class="responsive" style="padding-top: 20px; padding-bottom: 20px;" src="{{ config('app.url') }}/assets/images/facebook_43x42.png">
                      </a>

                   </td>
                   <td>
                      <a href="https://twitter.com" target="_blank">
                         <img class="responsive" style="padding-top: 20px; padding-bottom: 20px;" src="{{ config('app.url') }}/assets/images/twitter_43x42.png">
                      </a>

                   </td>
                   <td>
                      <a href="https://www.linkedin.com" target="_blank">
                         <img class="responsive" style="padding-top: 20px; padding-bottom: 20px;" src="{{ config('app.url') }}/assets/images/linkedin_43x42.png">
                      </a>

                   </td>
                   <td>
                      <a href="https://www.youtube.com" target="_blank">
                         <img class="responsive" style="padding-top: 20px; padding-bottom: 20px;" src="{{ config('app.url') }}/assets/images/youtube_43x42.png">
                      </a>

                   </td>
                </tr>
             </table>
          </td>
       </tr>
    </tbody>
 </table>

 <table align="center" class="module" role="module" data-type="spacer" border="0" cellpadding="0" cellspacing="0" width="100%" style="width:100%; max-width:600px;table-layout: fixed;" data-muid="a95f81e0-95d3-43b1-90ab-c7fbc108dffb">
    <tbody>
       <tr>
          <td style="padding:0px 0px 1px 0px;" role="module-content" bgcolor="#FFFFFF">
          </td>
       </tr>
    </tbody>
 </table>

 <table align="center" class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="width:100%; max-width:600px;table-layout: fixed;" data-muid="b712f382-b2b9-4d4d-8c0d-f370272e6f8b" data-mc-module-version="2019-10-22">
    <tbody>
       <tr>
          <td style="padding:20px 40px 20px 40px; line-height:17px; text-align:inherit; background-color:#000000;" height="100%" valign="top" bgcolor="#000000" role="module-content">
             <div>
                <div style="font-family: inherit; text-align: center"><span style="box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image-source: initial; border-image-slice: initial; border-image-width: initial; border-image-outset: initial; border-image-repeat: initial; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: pre-wrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; color: #f6f6f6; float: none; display: inline; font-size: 12px">En cumplimiento de la Ley 0001, de Servicios de la Sociedad de la Información y del Comercio electrónico y de la Ley Orgánica 0002, de Protección de Datos de Carácter Personal, le informamos que su dirección de correo electrónico ha sido obtenida de nuestros ficheros que se encuentran debidamente inscritos en nuestra bases de datos de Jimbo Sorteos.</span></div>
                <div></div>
             </div>
          </td>
       </tr>
       <tr>
        <td style="padding:20px 40px 20px 40px; line-height:17px; text-align:inherit; background-color:#000000;" height="100%" valign="top" bgcolor="#000000" role="module-content">
           <div>
              <div style="font-family: inherit; text-align: center"><span style="box-sizing: border-box; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-top-style: initial; border-right-style: initial; border-bottom-style: initial; border-left-style: initial; border-top-color: initial; border-right-color: initial; border-bottom-color: initial; border-left-color: initial; border-image-source: initial; border-image-slice: initial; border-image-width: initial; border-image-outset: initial; border-image-repeat: initial; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: pre-wrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; color: #f6f6f6; float: none; display: inline; font-size: 12px">© {{date('Y')}} Jimbo Sorteos. Todos los derechos reservados.</span></div>
              <div></div>
           </div>
        </td>
     </tr>
    </tbody>
 </table>
