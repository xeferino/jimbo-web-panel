<table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="b673c955-deb2-4a92-bed3-b3c26a1f6ed3">
    <tbody>
        <tr>
            <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="center">
                <img class="max-width" border="0" style="display:block; color:#000000; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px; max-width:100% !important; width:50%; height:auto !important;" alt="" data-proportionally-constrained="true" data-responsive="true" src="{{ config('app.url') }}/assets/images/{{$image}}">
            </td>
        </tr>
    </tbody>
</table>
